var papertemplate = require('./papertemplate');

exports.profile = papertemplate('waterfall'); 